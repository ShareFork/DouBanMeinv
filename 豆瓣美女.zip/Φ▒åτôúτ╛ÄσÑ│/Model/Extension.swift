//
//  Extension.swift
//  豆瓣美女
//
//  Created by lu on 15/12/15.
//  Copyright © 2015年 lu. All rights reserved.
//

import Foundation
import UIKit

extension UIColor{
    class func mainColor() ->UIColor{
//        return UIColor(red: 231/255, green: 45/255, blue: 48/255, alpha: 1)
        return UIColor.grayColor()
    }
}
