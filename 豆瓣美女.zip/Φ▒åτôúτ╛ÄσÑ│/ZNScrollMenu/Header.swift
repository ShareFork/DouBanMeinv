//
//  Header.swift
//  ScrollMenu
//
//  Created by zn on 15/7/16.
//  Copyright © 2015年 zn. All rights reserved.
//

import UIKit

let kStatusHeight =  UIApplication.sharedApplication().statusBarFrame.size.height
let kScreenSize = UIScreen.mainScreen().bounds.size

