//
//  BrowserCellDelegate.swift
//  PhotoBrowser
//
//  Created by lu on 15/12/6.
//  Copyright © 2015年 lu. All rights reserved.
//

import Foundation

protocol BrowserCellDelagate: NSObjectProtocol{
    func singleTap()
}